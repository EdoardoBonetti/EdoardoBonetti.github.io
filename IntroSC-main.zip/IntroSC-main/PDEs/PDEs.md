# Partial differential equations

- Poisson Equation and the 5-point stencil
- Iterative Solvers
- Wave equation
- Navier Stokes Equation

