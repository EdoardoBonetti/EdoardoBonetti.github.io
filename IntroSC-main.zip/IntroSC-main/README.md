# IntroSC
Lecture notes Introduction to Scientific Computing

[read online](https://jschoeberl.github.io/IntroSC/intro.html)

