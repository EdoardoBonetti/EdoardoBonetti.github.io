# Overview

We are developing a library for basic linear algebra operations. For this we
are implementing classes for vectors and matrices in modern C++,
make them available to Python for simple usability. 
We are practicing software development in teams using git, and start with
maintaining documentation from the beginning.

We learn tricks like expression templates to combine performance and
readability. We learn how modern CPUs operate, and design algorithms to utilize the potential.






